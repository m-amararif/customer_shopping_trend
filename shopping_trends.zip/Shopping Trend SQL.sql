SELECT TOP (1000) [Customer_ID]
      ,[Age]
      ,[Gender]
      ,[Item_Purchased]
      ,[Category]
      ,[Purchase_Amount_USD]
      ,[Location]
      ,[Size]
      ,[Color]
      ,[Season]
      ,[Review_Rating]
      ,[Subscription_Status]
      ,[Payment_Method]
      ,[Shipping_Type]
      ,[Discount_Applied]
      ,[Promo_Code_Used]
      ,[Previous_Purchases]
      ,[Preferred_Payment_Method]
      ,[Frequency_of_Purchases]
  FROM [Shopping Trend].[dbo].[shopping_trends]


  --Adding new column for Review Category--
 alter table shopping_trends
 add Review_Category varchar(300)

 update shopping_trends
 set Review_Category =
 case   when review_rating < 3 then 'Below Average'
		when review_rating >=3 and Review_Rating < 4 then 'Average'
		when review_rating >=4 and Review_Rating < 5 then 'Above Average'
		when review_rating = 5 then 'Excellent'
		else 'Not Reviewed'
 end;

 --Adding new column for Age Category--
 alter table shopping_trends
 add age_category varchar(300)

 update shopping_trends
 set age_category = 
 case  WHEN age < 18 THEN 'Under 18'
       WHEN age BETWEEN 18 AND 25 THEN '18-25'
       WHEN age BETWEEN 26 AND 35 THEN '26-35'
       WHEN age BETWEEN 36 AND 45 THEN '36-45'
       WHEN age BETWEEN 46 AND 55 THEN '46-55'
       WHEN age BETWEEN 56 AND 65 THEN '56-65'
       WHEN age BETWEEN 66 AND 70 THEN '66-70'
       ELSE 'Over 70'
  END;


--Total sales from the dataset--
select sum(purchase_amount_usd) as Total_Sales from shopping_trends --Total Sales USD 233,081

--Total item sold--
select COUNT(customer_id) from shopping_trends  --3900 units

--Percentage of Male and Female--
select Gender, count(customer_id) as TotalCount,
	count(customer_id) * 100/ sum(count(customer_id)) over () as percentage
from shopping_trends
group by Gender;


--Count of item purchased by category--
--Below is count per category
SELECT
    category,
    COUNT(customer_id) as TotalItem,
    SUM(Purchase_amount_usd) as TotalSales,
    CAST((COUNT(customer_id) * 100.0) / SUM(COUNT(customer_id)) OVER () AS DECIMAL(10,2)) as item_percent,
    CAST((SUM(Purchase_amount_usd) * 100.0) / SUM(SUM(Purchase_amount_usd)) OVER () AS DECIMAL (10,2)) as sales_percent
FROM shopping_trends
GROUP BY category;

--Calculate sales by age category
SELECT
    age_category,
    COUNT(customer_id) as TotalItem,
	CAST((COUNT(customer_id) * 100.0) / SUM(COUNT(customer_id)) OVER () AS DECIMAL(10,2)) as item_percent,
    SUM(Purchase_amount_usd) as TotalSales,
    CAST((SUM(Purchase_amount_usd) * 100.0) / SUM(SUM(Purchase_amount_usd)) OVER () AS DECIMAL (10,2)) as sales_percent
FROM shopping_trends
GROUP BY age_category;


--Total sales and percentage by location
select Location, sum(purchase_amount_usd) as TotalSales, 
cast((sum(Purchase_Amount_USD) * 100.0/sum(sum(Purchase_Amount_USD)) over ()) as decimal (10,2)) as Percentage
from shopping_trends
group by Location;


--Total Sales and percentage of sales by season
select season, sum(purchase_amount_usd) as TotalSales,
	cast((sum(purchase_amount_usd) * 100.0/sum(sum(purchase_amount_usd)) over ()) as decimal (10,2)) as percentage
from shopping_trends
group by Season;

--Total count of customer by Payment Method
select payment_method, count(customer_id) as TotalCount,
	sum(customer_id) * 100/ sum(sum(customer_id)) over () as percentage
from shopping_trends
group by payment_method;


--Number of item and sales by shipping type
select shipping_type, 
count(customer_id) as TotalCount, 
cast((count(customer_id) * 100.0/sum(count(customer_id)) over ()) as decimal (10,2)) as item_percent,
sum(purchase_amount_usd) as TotalSales,
cast((sum(purchase_amount_usd) * 100.0/sum(sum(purchase_amount_usd)) over ()) as decimal (10,2)) as sales_percent
from shopping_trends
group by shipping_type;
	
--Top item purchase by sales
select item_purchased, sum(purchase_amount_usd) as TotalSales
from shopping_trends
group by item_purchased
order by TotalSales desc

--Top item purchase by count of item
select item_purchased, count(customer_id) as TotalItem
from shopping_trends
group by item_purchased
order by TotalItem desc

-- Most purchase size by sales and count of item
select size, sum(purchase_amount_usd) as TotalSales, count(customer_id) as TotalItem,
cast((sum(purchase_amount_usd) * 100.0/sum(sum(purchase_amount_usd)) over ()) as decimal (10,2)) as sales_percent,
cast((count(customer_id) * 100.0/sum(count(customer_id)) over ()) as decimal (10,2)) as item_percent
from shopping_trends
group by size
order by TotalSales desc, TotalItem desc, sales_percent desc, item_percent desc;

-- TO see Item Purchase with Excellent Review
select item_purchased, Review_Category 
from shopping_trends
where Review_Category = 'Excellent'
